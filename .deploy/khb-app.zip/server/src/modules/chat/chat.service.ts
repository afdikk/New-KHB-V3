import { randomUUID } from 'node:crypto';
import { prisma } from '../../config/prisma';
import { badRequest } from '../../common/errors/app-error';
import { answerQuestion } from '../ai/answer.service';
import { isLlmEnabled } from '../ai/llm.client';
import { getWorkspace } from '../../common/workspace';
import { getAnswerDocuments } from '../knowledge/knowledge.service';
import { touchCustomer } from '../customers/customers.service';
import { resolveWidgetTheme, type WidgetTheme } from './widget-themes';

export interface ChatBootPayload {
  workspace: { name: string; slug: string; city: string | null; tagline: string | null };
  assistant: { name: string; greeting: string; language: string; showSources: boolean };
  /** Tema tampilan widget (warna + animasi Lottie) yang dipilih admin. */
  theme: WidgetTheme;
  starters: string[];
  capabilities: { rag: boolean; general: boolean };
}

/** Data awal untuk widget/halaman chat publik sebelum percakapan dimulai. */
export async function chatBoot(slug: string): Promise<ChatBootPayload> {
  const workspace = await getWorkspace(slug);
  const [documentCount, flowNodes] = await Promise.all([
    prisma.knowledgeDocument.count({ where: { workspaceId: workspace.id, status: 'indexed' } }),
    prisma.flowNode.findMany({
      where: { workspaceId: workspace.id, isActive: true },
      orderBy: { sortOrder: 'asc' },
      take: 6,
    }),
  ]);

  const starters = flowNodes
    .filter((node) => node.kind === 'question')
    .map((node) => node.title)
    .slice(0, 4);

  return {
    workspace: {
      name: workspace.name,
      slug: workspace.slug,
      city: workspace.city,
      tagline: workspace.tagline,
    },
    assistant: {
      name: workspace.settings.assistantName,
      greeting: workspace.settings.greeting,
      language: workspace.settings.language,
      showSources: workspace.settings.showSources,
    },
    theme: resolveWidgetTheme(workspace.settings.widgetTheme),
    starters,
    capabilities: { rag: documentCount > 0, general: isLlmEnabled() },
  };
}

export interface SendMessageInput {
  slug: string;
  message: string;
  sessionKey?: string;
  customerName?: string;
  /** Pelanggan yang sudah terverifikasi identitasnya (chat publik). */
  customerId?: string;
}

export interface SendMessageResult {
  conversationId: string;
  sessionKey: string;
  answer: string;
  source: 'rag' | 'general' | 'handoff' | 'none';
  grounded: boolean;
  citations: string[];
  confidence: number;
  note?: string;
  route: string;
  assistantName: string;
  createdAt: string;
}

/**
 * Satu giliran percakapan: simpan pertanyaan, jawab (RAG → dokumen lokal →
 * LLM umum → handoff), lalu simpan jawaban beserta sumbernya.
 */
export async function sendMessage(input: SendMessageInput): Promise<SendMessageResult> {
  const question = input.message.trim();
  if (question.length < 2) throw badRequest('Pertanyaan terlalu pendek');
  if (question.length > 2_000) throw badRequest('Pertanyaan maksimal 2000 karakter');

  const workspace = await getWorkspace(input.slug);
  const sessionKey = input.sessionKey?.trim() || randomUUID();

  let conversation = await prisma.conversation.findFirst({
    where: { workspaceId: workspace.id, sessionKey, status: { not: 'resolved' } },
  });

  if (!conversation) {
    const channel = await prisma.channel.findFirst({
      where: { workspaceId: workspace.id, platform: 'web' },
    });
    const customer = input.customerId
      ? await prisma.customer.findUnique({ where: { id: input.customerId } })
      : await touchCustomer(workspace.id, input.customerName);
    conversation = await prisma.conversation.create({
      data: {
        workspaceId: workspace.id,
        channelId: channel?.id ?? null,
        customerId: customer?.id ?? null,
        customerName: input.customerName?.trim() || 'Pengunjung web',
        sessionKey,
        status: 'bot',
        lastMessageAt: new Date(),
      },
    });
  }

  const previous = await prisma.message.findMany({
    where: { conversationId: conversation.id },
    orderBy: { createdAt: 'desc' },
    take: 8,
  });

  const history = previous
    .slice()
    .reverse()
    .map((message) => ({
      role: message.senderType === 'customer' ? ('user' as const) : ('assistant' as const),
      content: message.text,
    }));

  await prisma.message.create({
    data: {
      conversationId: conversation.id,
      senderType: 'customer',
      text: question,
      source: 'none',
    },
  });

  const documents = await getAnswerDocuments(workspace.id);

  const result = await answerQuestion({
    settings: workspace.settings,
    workspaceId: workspace.id,
    workspaceSlug: workspace.slug,
    question,
    history,
    documents,
    customerName: conversation.customerName ?? input.customerName,
  });

  const botMessage = await prisma.message.create({
    data: {
      conversationId: conversation.id,
      senderType: 'bot',
      text: result.answer,
      source: result.source,
      grounded: result.grounded,
      confidence: result.confidence,
      citations: result.citations,
    },
  });

  const escalated = result.source === 'handoff' && workspace.settings.autoEscalate;

  await prisma.conversation.update({
    where: { id: conversation.id },
    data: {
      lastMessageAt: new Date(),
      status: escalated ? 'pending_human' : conversation.status,
    },
  });

  // Beri tahu admin di lonceng saat percakapan perlu ditindaklanjuti manusia.
  if (escalated) {
    await prisma.notification.create({
      data: {
        workspaceId: workspace.id,
        type: 'chat',
        title: `Perlu pendamping: ${input.customerName?.trim() || 'Pengunjung web'}`,
        description: question.slice(0, 160),
      },
    });
  }

  return {
    conversationId: conversation.id,
    sessionKey,
    answer: result.answer,
    source: result.source,
    grounded: result.grounded,
    citations: result.citations,
    confidence: result.confidence,
    note: result.note,
    route: result.route,
    assistantName: workspace.settings.assistantName,
    createdAt: botMessage.createdAt.toISOString(),
  };
}

/** Riwayat percakapan satu sesi widget. */
export async function getSessionHistory(slug: string, sessionKey: string) {
  const workspace = await getWorkspace(slug);
  const conversation = await prisma.conversation.findFirst({
    where: { workspaceId: workspace.id, sessionKey },
    orderBy: { createdAt: 'desc' },
    include: { messages: { orderBy: { createdAt: 'asc' } } },
  });
  if (!conversation) return { sessionKey, messages: [] as Array<Record<string, unknown>> };

  return {
    sessionKey,
    conversationId: conversation.id,
    messages: conversation.messages.map((message) => ({
      id: message.id,
      senderType: message.senderType,
      text: message.text,
      source: message.source,
      citations: (message.citations as string[] | null) ?? [],
      createdAt: message.createdAt.toISOString(),
    })),
  };
}

// ── Chat publik: identitas wajib + riwayat per pengunjung ────────────────────

const CONTACT_PATTERN = /^(?:[^@\s]+@[^@\s]+\.[^@\s]{2,}|\+?62[0-9]{7,14}|0[0-9]{7,14})$/;

export interface VisitorIdentity {
  token: string;
  customer: { id: string; name: string; contact: string };
}

/**
 * Simpan identitas pengunjung (nama + WhatsApp/email) dan terbitkan token
 * peramban. Token inilah yang dipakai untuk membaca riwayat percakapannya —
 * bukan nomor telepon, agar orang lain tidak bisa membuka riwayat hanya dengan
 * mengetahui nomor.
 */
export async function registerVisitor(input: {
  slug: string;
  name: string;
  contact: string;
}): Promise<VisitorIdentity> {
  const name = input.name.trim();
  const contact = input.contact.trim();
  if (name.length < 2) throw badRequest('Nama minimal 2 karakter');
  if (!CONTACT_PATTERN.test(contact.replace(/[\s-]/g, ''))) {
    throw badRequest('Isi nomor WhatsApp (mis. 0812xxxxxxx) atau email yang valid');
  }

  const workspace = await getWorkspace(input.slug);
  const existing = await prisma.customer.findFirst({
    where: { workspaceId: workspace.id, contact },
  });

  const customer = existing
    ? await prisma.customer.update({
        where: { id: existing.id },
        data: {
          name,
          contact,
          portalToken: existing.portalToken ?? randomUUID(),
          lastSeenAt: new Date(),
        },
      })
    : await prisma.customer.create({
        data: {
          workspaceId: workspace.id,
          name,
          contact,
          portalToken: randomUUID(),
          status: 'Baru',
          lastSeenAt: new Date(),
        },
      });

  return {
    token: customer.portalToken ?? '',
    customer: { id: customer.id, name: customer.name, contact: customer.contact ?? contact },
  };
}

/** Cari pelanggan dari token peramban; menolak bila token tidak dikenal. */
async function requireVisitor(slug: string, token: string) {
  const workspace = await getWorkspace(slug);
  const customer = token
    ? await prisma.customer.findFirst({ where: { workspaceId: workspace.id, portalToken: token } })
    : null;
  if (!customer) throw badRequest('Isi data diri terlebih dahulu sebelum memulai percakapan');
  return { workspace, customer };
}

/** Kirim pesan sebagai pengunjung yang identitasnya sudah terdaftar. */
export async function sendVisitorMessage(input: {
  slug: string;
  token: string;
  message: string;
  sessionKey?: string;
}): Promise<SendMessageResult> {
  const { customer } = await requireVisitor(input.slug, input.token);
  return sendMessage({
    slug: input.slug,
    message: input.message,
    sessionKey: input.sessionKey,
    customerName: customer.name,
    customerId: customer.id,
  });
}

export interface VisitorSession {
  conversationId: string;
  sessionKey: string;
  title: string;
  snippet: string;
  lastMessageAt: string | null;
  messageCount: number;
  status: string;
}

/** Daftar percakapan milik satu pengunjung (terbaru lebih dulu). */
export async function listVisitorSessions(slug: string, token: string): Promise<VisitorSession[]> {
  const { workspace, customer } = await requireVisitor(slug, token);

  const conversations = await prisma.conversation.findMany({
    where: { workspaceId: workspace.id, customerId: customer.id },
    orderBy: [{ lastMessageAt: 'desc' }, { createdAt: 'desc' }],
    take: 30,
    include: {
      messages: { orderBy: { createdAt: 'asc' }, take: 40 },
      _count: { select: { messages: true } },
    },
  });

  return conversations.map((conversation) => {
    const firstQuestion = conversation.messages.find((message) => message.senderType === 'customer');
    const lastMessage = conversation.messages[conversation.messages.length - 1];
    return {
      conversationId: conversation.id,
      sessionKey: conversation.sessionKey ?? conversation.id,
      title: firstQuestion?.text.slice(0, 70) ?? 'Percakapan baru',
      snippet: (lastMessage?.text ?? '').replace(/\s+/g, ' ').slice(0, 90),
      lastMessageAt: conversation.lastMessageAt?.toISOString() ?? null,
      messageCount: conversation._count.messages,
      status: conversation.status,
    };
  });
}

/** Transkrip satu percakapan milik pengunjung (dibatasi token-nya). */
export async function getVisitorSession(slug: string, token: string, conversationId: string) {
  const { workspace, customer } = await requireVisitor(slug, token);

  const conversation = await prisma.conversation.findFirst({
    where: { id: conversationId, workspaceId: workspace.id, customerId: customer.id },
    include: { messages: { orderBy: { createdAt: 'asc' } } },
  });
  if (!conversation) throw badRequest('Percakapan tidak ditemukan');

  return {
    conversationId: conversation.id,
    sessionKey: conversation.sessionKey ?? conversation.id,
    messages: conversation.messages.map((message) => ({
      id: message.id,
      senderType: message.senderType,
      text: message.text,
      source: message.source,
      citations: (message.citations as string[] | null) ?? [],
      createdAt: message.createdAt.toISOString(),
    })),
  };
}
